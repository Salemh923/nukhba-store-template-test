
let storeConfig = {};
let products = [];

async function loadConfig() {
  try {
    const res = await fetch("config.json");
    storeConfig = await res.json();
    products = storeConfig.products || [];
    
    // تحديث شعار المتجر وعنوان الصفحة
    const logoEl = document.querySelector(".logo");
    if (logoEl) logoEl.innerHTML = `<span>${storeConfig.site.name}</span>`;
    document.title = storeConfig.site.name;

    // تحديث القائمة الرئيسية ديناميكياً
    const navContainer = document.querySelector(".menu .container, nav");
    if(navContainer && storeConfig.navigation) {
      navContainer.innerHTML = storeConfig.navigation.map(item =>
        `<a href="${item.url}">${item.label}</a>`).join("");
    }

    // تحديث البانرات
    if(storeConfig.banners?.hero) {
      const hero = document.querySelector(".hero");
      if(hero) hero.style.backgroundImage = `url(${storeConfig.banners.hero.image})`;
      const hTitle = document.querySelector(".hero-content h1");
      if(hTitle) hTitle.innerText = storeConfig.banners.hero.title;
      const hSub = document.querySelector(".hero-content p");
      if(hSub) hSub.innerText = storeConfig.banners.hero.subtitle;
    }
    if(storeConfig.banners?.trust) {
      const trust = document.querySelector(".trust-banner, .trust");
      if(trust) trust.style.backgroundImage = `url(${storeConfig.banners.trust.image})`;
    }

    renderProducts();
    updateCounters();
  } catch(e) {
    console.error("Failed to load config.json", e);
  }
}

function renderProducts() {
  const productsContainer = document.querySelector("[data-template-products], #products, .products-grid, .featured-products");
  if(productsContainer) {
    productsContainer.innerHTML = products.map(p => `
      <article class="template-card product-card" data-category="${p.category || ''}">
        <div class="template-badge">${p.badge || ''}</div>
        <img src="${p.image}" alt="${p.name || ''}">
        <div class="template-card-body">
          <h3>${p.name}</h3>
          <p class="template-price">${p.price} ${storeConfig.site.currency || ''}</p>
          ${p.oldPrice ? `<p class="template-old-price">${p.oldPrice} ${storeConfig.site.currency || ''}</p>` : ''}
          <button class="template-btn" data-product-id="${p.id || ''}">أضف للسلة</button>
        </div>
      </article>
    `).join("");
  }
}

// استدعاء التحميل
document.addEventListener("DOMContentLoaded", () => {
  loadConfig();
});
