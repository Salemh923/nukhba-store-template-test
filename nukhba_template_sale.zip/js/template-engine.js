
(function () {
  const defaultConfig = window.NUKHBA_CONFIG || {};
  const isPage = location.pathname.includes('/pages/');
  const base = isPage ? '../' : '';

  function resolve(path) {
    if (!path) return '';
    if (/^(https?:)?\/\//.test(path) || path.startsWith('data:')) return path;
    return base + path.replace(/^\.?\//, '');
  }

  async function loadConfig() {
    try {
      const res = await fetch(base + 'config.json', { cache: 'no-store' });
      if (!res.ok) throw new Error('config not found');
      return await res.json();
    } catch (e) {
      return defaultConfig;
    }
  }

  function applyTheme(config) {
    const theme = config.theme || {};
    const root = document.documentElement;
    const vars = {
      '--template-primary': theme.primaryColor,
      '--template-secondary': theme.secondaryColor,
      '--template-accent': theme.accentColor,
      '--template-bg': theme.backgroundColor,
      '--template-text': theme.textColor,
      '--template-radius': theme.borderRadius,
      '--template-font': theme.fontFamily
    };
    Object.entries(vars).forEach(([k, v]) => v && root.style.setProperty(k, v));
    if (config.site?.direction) document.documentElement.dir = config.site.direction;
    if (config.site?.language) document.documentElement.lang = config.site.language;
    document.title = config.site?.name || document.title;
  }

  function setText(selector, text) {
    if (text == null) return;
    document.querySelectorAll(selector).forEach(el => el.textContent = text);
  }

  function setImages(config) {
    document.querySelectorAll('img').forEach(img => {
      const src = img.getAttribute('src') || '';
      if (src.includes('logo') && config.site?.logo) img.src = resolve(config.site.logo);
      if (src.includes('hero-banner') && config.banners?.hero?.image) img.src = resolve(config.banners.hero.image);
      if (src.includes('trust-banner') && config.banners?.trust?.image) img.src = resolve(config.banners.trust.image);
    });
  }

  function productCard(product, currency) {
    return `
      <article class="template-card product-card" data-category="${product.category || ''}">
        <div class="template-badge">${product.badge || ''}</div>
        <img src="${resolve(product.image)}" alt="${product.name || ''}">
        <div class="template-card-body">
          <h3>${product.name || ''}</h3>
          <p class="template-price">${product.price || 0} ${currency || ''}</p>
          ${product.oldPrice ? `<p class="template-old-price">${product.oldPrice} ${currency || ''}</p>` : ''}
          <button class="template-btn" data-product-id="${product.id || ''}">أضف للسلة</button>
        </div>
      </article>
    `;
  }

  function categoryCard(category) {
    return `
      <article class="template-card category-card" data-category="${category.id || ''}">
        <img src="${resolve(category.image)}" alt="${category.name || ''}">
        <div class="template-card-body">
          <h3>${category.name || ''}</h3>
        </div>
      </article>
    `;
  }

  function renderDynamicSections(config) {
    const currency = config.site?.currency || '';
    const productsHTML = (config.products || []).map(p => productCard(p, currency)).join('');
    const categoriesHTML = (config.categories || []).map(categoryCard).join('');

    document.querySelectorAll('[data-template-products], #products, .products-grid, .featured-products').forEach(el => {
      if (productsHTML) el.innerHTML = productsHTML;
    });

    document.querySelectorAll('[data-template-categories], #categories, .categories-grid').forEach(el => {
      if (categoriesHTML) el.innerHTML = categoriesHTML;
    });
  }

  function renderNav(config) {
    const navHTML = (config.navigation || []).map(item => {
      const url = item.url?.startsWith('pages/') && isPage ? '../' + item.url : item.url;
      return `<a href="${url || '#'}">${item.label || ''}</a>`;
    }).join('');
    document.querySelectorAll('[data-template-nav]').forEach(el => el.innerHTML = navHTML);
  }

  function injectTemplateStyles() {
    const css = `
      :root {
        --template-primary:#0f172a;
        --template-secondary:#c9a227;
        --template-accent:#16a34a;
        --template-bg:#ffffff;
        --template-text:#111827;
        --template-radius:18px;
        --template-font:Tajawal, Arial, sans-serif;
      }
      body { font-family: var(--template-font); background: var(--template-bg); color: var(--template-text); }
      .template-btn, button, .btn { border-radius: var(--template-radius); background: var(--template-primary); color:#fff; border:0; cursor:pointer; }
      .template-card { position:relative; border-radius:var(--template-radius); overflow:hidden; background:#fff; box-shadow:0 10px 30px rgba(15,23,42,.08); transition:.25s; }
      .template-card:hover { transform:translateY(-4px); }
      .template-card img { width:100%; height:220px; object-fit:cover; display:block; }
      .template-card-body { padding:16px; }
      .template-price { color:var(--template-accent); font-weight:800; }
      .template-old-price { opacity:.6; text-decoration:line-through; }
      .template-badge { position:absolute; top:12px; inset-inline-start:12px; background:var(--template-secondary); color:#fff; padding:6px 12px; border-radius:999px; z-index:2; font-size:13px; }
      [data-template-nav] { display:flex; gap:18px; align-items:center; flex-wrap:wrap; }
      [data-template-nav] a { color:var(--template-primary); text-decoration:none; font-weight:700; }
    `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  document.addEventListener('DOMContentLoaded', async () => {
    injectTemplateStyles();
    const config = await loadConfig();
    window.NUKHBA_TEMPLATE_CONFIG = config;
    applyTheme(config);
    setText('[data-site-name]', config.site?.name);
    setText('[data-hero-title]', config.banners?.hero?.title);
    setText('[data-hero-subtitle]', config.banners?.hero?.subtitle);
    setImages(config);
    renderNav(config);
    renderDynamicSections(config);
  });
})();
